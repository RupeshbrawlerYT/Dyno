# warning this bot can be destructive

what can this bot do you may ask well this bot can destroy servers if it has admin
it can spam and it can ban everyone
