# raid-bots-discord
# warning these bots are destructive

if you want to support my work creating these bots to assist in raiding discord servers then please check out my patreon
